package western;

public enum Genre { FEMININ, MASCULIN }
