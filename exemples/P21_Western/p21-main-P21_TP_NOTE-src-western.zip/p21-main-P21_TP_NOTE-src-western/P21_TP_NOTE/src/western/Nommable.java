package western;

public interface Nommable
{
    String getNom();
    String getPseudo();
}
